window.FileConverter = FileConverter;
window.FileSelector = FileSelector;
window.FileBufferReader = FileBufferReader;
})();
