window.RTCMultiConnection = RTCMultiConnection;
})();
