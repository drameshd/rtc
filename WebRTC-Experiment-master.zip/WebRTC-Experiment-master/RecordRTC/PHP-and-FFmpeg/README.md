# RecordRTC / PHP / FFmpeg

https://github.com/muaz-khan/WebRTC-Experiment/tree/master/RecordRTC/PHP-and-FFmpeg

This demo can:

1. record both audio/video
2. merge in single WebM using ffmpeg
3. audio is synced with video using ffmpeg commands!
4. it supports longest possible recordings!